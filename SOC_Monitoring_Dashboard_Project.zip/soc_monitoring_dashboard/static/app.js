(() => {
  'use strict';
  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => Array.from(root.querySelectorAll(selector));
  const COLORS = { Critical: '#e45768', High: '#ee8b64', Medium: '#edae45', Low: '#7288ed', Info: '#39b998' };
  let dashboardData = null;
  let eventsCache = [];
  let lastEventsResponse = { events: [], event_types: [] };
  let alertItems = [];
  let debounceHandles = {};

  function escapeHtml(value) {
    return String(value ?? '').replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));
  }
  function fmtTime(value) {
    if (!value) return '—';
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return String(value);
    return date.toLocaleString([], { month: 'short', day: '2-digit', hour: '2-digit', minute: '2-digit' });
  }
  function fmtDay(value) {
    const date = new Date(`${value}T12:00:00`);
    return Number.isNaN(date.getTime()) ? value : date.toLocaleDateString([], { weekday: 'short' });
  }
  function severityClass(value) { return String(value || 'info').toLowerCase().replace(/[^a-z]/g, ''); }
  function statusClass(value) { return String(value || 'new').toLowerCase().replace(/\s+/g, '-'); }
  function severityPill(value) { return `<span class="severity-pill ${severityClass(value)}">${escapeHtml(value || 'Info')}</span>`; }
  function statusPill(value) { return `<span class="status-pill ${statusClass(value)}">${escapeHtml(value || 'New')}</span>`; }
  function toast(message, type = 'success') {
    const container = $('#toast-container');
    const item = document.createElement('div');
    item.className = `toast ${type}`;
    item.textContent = message;
    container.appendChild(item);
    window.setTimeout(() => item.remove(), 4000);
  }
  async function requestJson(url, options = {}) {
    const response = await fetch(url, options);
    let body;
    try { body = await response.json(); } catch { body = {}; }
    if (response.status === 401) { window.location.href = '/login'; throw new Error('Please sign in again.'); }
    if (!response.ok) throw new Error(body.error || `Request failed (${response.status}).`);
    return body;
  }
  function showView(name) {
    $$('.view').forEach(view => view.classList.toggle('active', view.id === `view-${name}`));
    $$('.nav-item').forEach(button => button.classList.toggle('active', button.dataset.view === name));
    $('#current-breadcrumb').textContent = ({ overview: 'Overview', events: 'Security events', alerts: 'Alert queue', ingest: 'Log ingestion' })[name] || 'Overview';
    $('#sidebar').classList.remove('open');
    if (name === 'events') loadEvents();
    if (name === 'alerts') loadAlerts();
  }
  function setDate() {
    $('#current-date').textContent = new Date().toLocaleDateString([], { weekday: 'short', month: 'short', day: 'numeric' });
  }
  function setText(selector, value) { const el = $(selector); if (el) el.textContent = value; }

  function drawTrend(canvas, trend) {
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const width = Math.max(260, rect.width || 500), height = Math.max(150, rect.height || 205);
    const dpr = window.devicePixelRatio || 1;
    canvas.width = Math.floor(width * dpr); canvas.height = Math.floor(height * dpr);
    const ctx = canvas.getContext('2d'); ctx.scale(dpr, dpr); ctx.clearRect(0, 0, width, height);
    const pad = { l: 27, r: 12, t: 12, b: 28 };
    const graphW = width - pad.l - pad.r, graphH = height - pad.t - pad.b;
    const values = trend.map(row => row.events || 0), highs = trend.map(row => row.high || 0);
    const max = Math.max(4, ...values, ...highs);
    ctx.font = '10px DM Sans, sans-serif'; ctx.textAlign = 'right'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#a3adbd';
    for (let i = 0; i <= 4; i++) {
      const y = pad.t + graphH * i / 4;
      ctx.strokeStyle = '#edf0f6'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(pad.l, y); ctx.lineTo(width - pad.r, y); ctx.stroke();
      ctx.fillText(String(Math.round(max * (4 - i) / 4)), pad.l - 8, y);
    }
    const x = index => pad.l + (trend.length <= 1 ? graphW / 2 : graphW * index / (trend.length - 1));
    const y = value => pad.t + graphH - (value / max) * graphH;
    function line(values, color, fill) {
      ctx.beginPath(); values.forEach((v, i) => { if (i === 0) ctx.moveTo(x(i), y(v)); else ctx.lineTo(x(i), y(v)); });
      if (fill) { ctx.lineTo(x(values.length - 1), pad.t + graphH); ctx.lineTo(x(0), pad.t + graphH); ctx.closePath(); ctx.fillStyle = fill; ctx.fill(); }
      else { ctx.strokeStyle = color; ctx.lineWidth = 2; ctx.lineJoin = 'round'; ctx.lineCap = 'round'; ctx.stroke(); }
      values.forEach((v, i) => { ctx.beginPath(); ctx.arc(x(i), y(v), 2.8, 0, Math.PI * 2); ctx.fillStyle = color; ctx.fill(); ctx.strokeStyle = '#fff'; ctx.lineWidth = 1.5; ctx.stroke(); });
    }
    line(values, '#5b78ed', 'rgba(91,120,237,.10)'); line(highs, '#e75c6e', null);
    ctx.fillStyle = '#9ca6b7'; ctx.textAlign = 'center'; ctx.textBaseline = 'top';
    trend.forEach((row, i) => ctx.fillText(fmtDay(row.date), x(i), height - pad.b + 10));
  }
  function drawDonut(canvas, items) {
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const size = Math.max(125, Math.min(rect.width || 160, rect.height || 160));
    const dpr = window.devicePixelRatio || 1;
    canvas.width = size * dpr; canvas.height = size * dpr; canvas.style.width = `${size}px`; canvas.style.height = `${size}px`;
    const ctx = canvas.getContext('2d'); ctx.scale(dpr, dpr); ctx.clearRect(0, 0, size, size);
    const cx = size / 2, cy = size / 2, radius = size * .43, thickness = size * .14;
    const total = items.reduce((n, row) => n + row.value, 0) || 1;
    let angle = -Math.PI / 2;
    const order = ['Critical', 'High', 'Medium', 'Low', 'Info'];
    const values = [...items].sort((a, b) => order.indexOf(a.name) - order.indexOf(b.name));
    values.forEach(item => {
      const span = Math.PI * 2 * item.value / total;
      if (span > 0) { ctx.beginPath(); ctx.arc(cx, cy, radius, angle, angle + span); ctx.strokeStyle = COLORS[item.name] || '#c6cedd'; ctx.lineWidth = thickness; ctx.lineCap = 'butt'; ctx.stroke(); }
      angle += span;
    });
    if (!items.length || items.reduce((n, row) => n + row.value, 0) === 0) {
      ctx.beginPath(); ctx.arc(cx, cy, radius, 0, Math.PI * 2); ctx.strokeStyle = '#edf0f6'; ctx.lineWidth = thickness; ctx.stroke();
    }
  }
  function renderSeverity(items) {
    const total = items.reduce((n, item) => n + item.value, 0);
    setText('#severity-total', total.toLocaleString());
    drawDonut($('#severity-chart'), items);
    $('#severity-legend').innerHTML = ['Critical', 'High', 'Medium', 'Low', 'Info'].map(name => {
      const match = items.find(x => x.name === name), count = match ? match.value : 0;
      return `<div class="legend-row"><i class="legend-color" style="background:${COLORS[name]}"></i><span>${name}</span><b>${count}</b></div>`;
    }).join('');
  }
  function renderTopSources(items) {
    const container = $('#top-sources');
    if (!items.length) { container.innerHTML = '<div class="empty">No source addresses found.</div>'; return; }
    const max = Math.max(...items.map(x => x.value), 1);
    container.innerHTML = items.map(item => `<div class="rank-row"><span class="rank-ip" title="${escapeHtml(item.name)}">${escapeHtml(item.name)}</span><div class="rank-track"><div class="rank-fill" style="width:${Math.max(5, item.value / max * 100)}%"></div></div><span class="rank-value">${item.value}</span></div>`).join('');
  }
  function renderLocations(items) {
    const container = $('#locations-list');
    if (!items.length) { container.innerHTML = '<div class="empty">No country data is present in the imported events.</div>'; return; }
    const icons = ['◎', '⌖', '◉', '◇', '⊙', '◌'];
    container.innerHTML = items.map((item, i) => `<div class="location-row"><div class="location-flag">${icons[i % icons.length]}</div><div class="location-info"><b>${escapeHtml(item.name)}</b><small>Events in the selected records</small></div><span class="location-value">${item.value}</span></div>`).join('');
  }
  function renderOverviewAlerts(alerts) {
    const body = $('#overview-alerts');
    if (!alerts.length) { body.innerHTML = '<tr><td colspan="4" class="empty">No alerts have been generated.</td></tr>'; return; }
    body.innerHTML = alerts.map(alert => `<tr><td><span class="det-title">${escapeHtml(alert.title)}</span><span class="cell-sub">${escapeHtml(alert.event_type)} · ${fmtTime(alert.last_seen)}</span></td><td><span class="ip-text">${escapeHtml(alert.source_ip)}</span></td><td>${severityPill(alert.severity)}</td><td>${statusPill(alert.status)}</td></tr>`).join('');
  }
  function renderOverviewEvents(events) {
    const body = $('#overview-events');
    if (!events.length) { body.innerHTML = '<tr><td colspan="4" class="empty">No events found.</td></tr>'; return; }
    body.innerHTML = events.map(event => `<tr><td>${fmtTime(event.timestamp)}</td><td><span class="event-title">${escapeHtml(event.event_type)}</span><span class="cell-sub">${escapeHtml(event.message)}</span></td><td><span class="ip-text">${escapeHtml(event.source_ip)}</span></td><td>${severityPill(event.severity)}</td></tr>`).join('');
  }
  async function loadDashboard() {
    try {
      const data = await requestJson('/api/summary'); dashboardData = data;
      setText('#metric-events', data.metrics.total_events.toLocaleString());
      setText('#metric-open', data.metrics.open_alerts.toLocaleString());
      setText('#metric-high', data.metrics.high_alerts.toLocaleString());
      setText('#metric-sources', data.metrics.unique_sources.toLocaleString());
      setText('#nav-events-count', data.metrics.total_events.toLocaleString());
      setText('#nav-alerts-count', data.metrics.open_alerts.toLocaleString());
      renderOverviewAlerts(data.alerts); renderOverviewEvents(data.events); renderTopSources(data.top_sources); renderLocations(data.countries); renderSeverity(data.severity); drawTrend($('#trend-chart'), data.trend);
    } catch (error) { toast(error.message || 'Unable to load dashboard data.', 'error'); }
  }
  function renderEventsTable(events) {
    const body = $('#events-table'); setText('#event-results-count', `${events.length} record${events.length === 1 ? '' : 's'}`);
    if (!events.length) { body.innerHTML = '<tr><td colspan="7" class="empty">No matching events. Try clearing the filters or import a log file.</td></tr>'; return; }
    body.innerHTML = events.map((event, i) => `<tr><td>${fmtTime(event.timestamp)}</td><td><span class="event-title">${escapeHtml(event.event_type)}</span><span class="cell-sub" title="${escapeHtml(event.message)}">${escapeHtml(event.message)}</span></td><td><span class="ip-text">${escapeHtml(event.source_ip)}</span><span class="cell-sub">${escapeHtml(event.username)}</span></td><td><span class="ip-text">${escapeHtml(event.destination_ip)}${event.destination_port ? ':' + escapeHtml(event.destination_port) : ''}</span></td><td>${escapeHtml(event.source)}</td><td>${severityPill(event.severity)}</td><td><button class="raw-button" data-raw-index="${i}">Raw log ↗</button></td></tr>`).join('');
  }
  async function loadEvents() {
    const params = new URLSearchParams();
    const q = $('#event-search').value.trim(), severity = $('#event-severity').value, eventType = $('#event-type').value;
    if (q) params.set('q', q); if (severity) params.set('severity', severity); if (eventType) params.set('event_type', eventType);
    try {
      const data = await requestJson(`/api/events?${params.toString()}`); lastEventsResponse = data; eventsCache = data.events;
      const typeSelect = $('#event-type'), oldVal = typeSelect.value;
      typeSelect.innerHTML = '<option value="">All event types</option>' + data.event_types.map(type => `<option value="${escapeHtml(type)}">${escapeHtml(type)}</option>`).join('');
      if (data.event_types.includes(oldVal)) typeSelect.value = oldVal;
      renderEventsTable(data.events);
    } catch (error) { toast(error.message || 'Unable to load events.', 'error'); }
  }
  function renderAlerts(alerts) {
    const container = $('#alerts-list'); setText('#alert-results-count', `${alerts.length} alert${alerts.length === 1 ? '' : 's'}`);
    const statusCounts = { 'New': 0, 'In Progress': 0, 'Resolved': 0, 'False Positive': 0 };
    alertItems.forEach(item => { if (statusCounts[item.status] !== undefined) statusCounts[item.status] += 1; });
    setText('#alert-new-count', statusCounts['New']); setText('#alert-progress-count', statusCounts['In Progress']); setText('#alert-resolved-count', statusCounts.Resolved); setText('#alert-fp-count', statusCounts['False Positive']);
    if (!alerts.length) { container.innerHTML = '<article class="panel empty">No alerts match these filters.</article>'; return; }
    const canEdit = ['Admin', 'Analyst'].includes(window.SOC_USER?.role);
    container.innerHTML = alerts.map(alert => `<article class="alert-card"><div class="alert-card-head"><div class="alert-severity-line ${severityClass(alert.severity)}"></div><div class="alert-card-main"><h3 class="alert-card-title">${escapeHtml(alert.title)}</h3><div class="alert-meta"><span>Alert #${alert.id}</span><span>Source <b class="ip-text">${escapeHtml(alert.source_ip)}</b></span><span>${escapeHtml(alert.event_type)}</span><span>${alert.event_count} event(s)</span><span>Last seen ${fmtTime(alert.last_seen)}</span></div></div><div>${severityPill(alert.severity)}<div style="margin-top:7px">${statusPill(alert.status)}</div></div></div><p class="alert-description">${escapeHtml(alert.details)}</p><div class="alert-edit"><div><label for="status-${alert.id}">Status</label><select id="status-${alert.id}" ${canEdit ? '' : 'disabled'}>${['New','In Progress','Resolved','False Positive'].map(s => `<option ${alert.status === s ? 'selected' : ''}>${s}</option>`).join('')}</select></div><div><label for="assignee-${alert.id}">Assigned to</label><select id="assignee-${alert.id}" ${canEdit ? '' : 'disabled'}>${['Unassigned','SOC Administrator','Security Analyst',window.SOC_USER?.display_name].filter((v,i,a) => a.indexOf(v) === i).map(v => `<option ${alert.assigned_to === v ? 'selected' : ''}>${escapeHtml(v)}</option>`).join('')}</select></div><div class="notes-field"><label for="notes-${alert.id}">Analyst notes</label><textarea id="notes-${alert.id}" placeholder="Record investigation findings…" ${canEdit ? '' : 'disabled'}>${escapeHtml(alert.notes || '')}</textarea></div><button class="btn primary save-alert" data-alert-id="${alert.id}" ${canEdit ? '' : 'disabled'}>Save update</button></div></article>`).join('');
  }
  async function loadAlerts() {
    const params = new URLSearchParams();
    const q = $('#alert-search').value.trim(), status = $('#alert-status-filter').value, severity = $('#alert-severity-filter').value;
    if (q) params.set('q', q); if (status) params.set('status', status); if (severity) params.set('severity', severity);
    try { const data = await requestJson(`/api/alerts?${params.toString()}`); alertItems = data.alerts; renderAlerts(data.alerts); }
    catch (error) { toast(error.message || 'Unable to load alerts.', 'error'); }
  }
  async function saveAlert(id) {
    const status = $(`#status-${id}`).value, assigned_to = $(`#assignee-${id}`).value, notes = $(`#notes-${id}`).value;
    try {
      await requestJson(`/api/alerts/${id}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ status, assigned_to, notes }) });
      toast(`Alert #${id} updated.`); await Promise.all([loadAlerts(), loadDashboard()]);
    } catch (error) { toast(error.message || 'Unable to update alert.', 'error'); }
  }
  function openRaw(index) {
    const event = eventsCache[index]; if (!event) return;
    const modal = $('#raw-modal');
    setText('#raw-modal-title', `Event #${event.id} · ${event.event_type}`);
    let raw = event.raw_log;
    try { raw = JSON.stringify(JSON.parse(raw), null, 2); } catch (_) { /* keep original raw text */ }
    $('#raw-log-content').textContent = raw || 'No raw payload was stored.';
    modal.hidden = false;
  }
  function openModal(id) { const modal = $(`#${id}`); if (modal) modal.hidden = false; }
  function closeModal(id) { const modal = $(`#${id}`); if (modal) modal.hidden = true; }
  function debounce(key, callback, delay = 250) { clearTimeout(debounceHandles[key]); debounceHandles[key] = setTimeout(callback, delay); }

  document.addEventListener('click', event => {
    const nav = event.target.closest('[data-view]');
    if (nav) { showView(nav.dataset.view); return; }
    const goto = event.target.closest('[data-goto]');
    if (goto) { showView(goto.dataset.goto); return; }
    const close = event.target.closest('[data-close]');
    if (close) { closeModal(close.dataset.close); return; }
    const raw = event.target.closest('[data-raw-index]');
    if (raw) { openRaw(Number(raw.dataset.rawIndex)); return; }
    const save = event.target.closest('.save-alert');
    if (save) { saveAlert(Number(save.dataset.alertId)); return; }
    if (event.target.classList.contains('modal-backdrop')) event.target.hidden = true;
  });
  $('#mobile-menu').addEventListener('click', () => $('#sidebar').classList.toggle('open'));
  $('#refresh-btn').addEventListener('click', async () => { await loadDashboard(); toast('Dashboard refreshed.'); });
  $('#refresh-alerts').addEventListener('click', loadAlerts);
  $('#quick-ingest').addEventListener('click', () => showView('ingest'));
  $('#dismiss-banner').addEventListener('click', () => { $('.demo-banner').style.display = 'none'; });
  $('#event-search').addEventListener('input', () => debounce('events', loadEvents));
  $('#event-severity').addEventListener('change', loadEvents); $('#event-type').addEventListener('change', loadEvents);
  $('#clear-event-filters').addEventListener('click', () => { $('#event-search').value = ''; $('#event-severity').value = ''; $('#event-type').value = ''; loadEvents(); });
  $('#alert-search').addEventListener('input', () => debounce('alerts', loadAlerts));
  $('#alert-status-filter').addEventListener('change', loadAlerts); $('#alert-severity-filter').addEventListener('change', loadAlerts);
  $('#add-event-btn')?.addEventListener('click', () => openModal('event-modal'));
  $('#log-file').addEventListener('change', () => { setText('#selected-file', $('#log-file').files[0]?.name || 'No file selected'); });
  $('#upload-form').addEventListener('submit', async event => {
    event.preventDefault();
    const form = event.currentTarget, button = $('#upload-btn'), result = $('#upload-result');
    if (!$('#log-file').files.length) { result.textContent = 'Choose a file first.'; result.className = 'upload-result error'; return; }
    button.disabled = true; button.textContent = 'Importing and analysing…'; result.textContent = ''; result.className = 'upload-result';
    try {
      const data = await requestJson('/api/ingest', { method: 'POST', body: new FormData(form) });
      result.textContent = data.message; result.className = 'upload-result success'; form.reset(); setText('#selected-file', 'No file selected');
      toast(data.message); await Promise.all([loadDashboard(), loadEvents(), loadAlerts()]);
    } catch (error) { result.textContent = error.message; result.className = 'upload-result error'; toast(error.message, 'error'); }
    finally { button.disabled = false; button.textContent = 'Import and analyse logs'; }
  });
  $('#manual-event-form').addEventListener('submit', async event => {
    event.preventDefault(); const form = event.currentTarget, button = $('button[type="submit"]', form); button.disabled = true;
    const payload = Object.fromEntries(new FormData(form).entries());
    try {
      const data = await requestJson('/api/events', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
      closeModal('event-modal'); form.reset(); toast(data.message); await Promise.all([loadDashboard(), loadEvents(), loadAlerts()]);
    } catch (error) { toast(error.message || 'Unable to add event.', 'error'); }
    finally { button.disabled = false; }
  });
  document.addEventListener('keydown', event => { if (event.key === 'Escape') $$('.modal-backdrop').forEach(modal => { modal.hidden = true; }); });

  if (window.SOC_USER?.role !== 'Admin') {
    $$('.admin-only').forEach(el => el.style.display = 'none');
    $('#nav-ingest').style.display = 'none';
    $('#quick-ingest').style.display = 'none';
  }
  setDate(); loadDashboard();
  window.addEventListener('resize', () => { if (dashboardData) { drawTrend($('#trend-chart'), dashboardData.trend); drawDonut($('#severity-chart'), dashboardData.severity); } });
})();
