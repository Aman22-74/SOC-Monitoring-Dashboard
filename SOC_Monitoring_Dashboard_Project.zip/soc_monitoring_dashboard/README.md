# SOC Monitoring Dashboard — Mini Project Prototype

**Project domain:** Cyber Security — security monitoring, log analysis, rule-based threat detection and incident triage.

This working local prototype follows the supplied *Security Operations Center Monitoring Dashboard* synopsis. It uses **Python 3, Flask, SQLite, HTML, CSS and JavaScript**. The interface and parsers are dependency-light so it can run on a student laptop without first installing a full SIEM stack.

> **Important scope note:** this build is a functioning dashboard prototype, not a deployed production SOC. It starts with simulated lab events and supports importing exported log files. It does **not** automatically connect to a running Wazuh manager, Suricata sensor, Elasticsearch/OpenSearch, Kibana/Grafana or threat-intelligence API. Import permitted exports from your own lab to demonstrate ingestion. The source structure can be extended to add those live integrations.

## Features implemented

- Dashboard overview with event counts, open/high-priority alert counts, unique source IPs, seven-day event chart and severity distribution.
- Central event table with search, severity and event-type filters, normalised fields and a raw-record drill-down.
- Log ingestion for **JSON, JSONL/NDJSON, CSV, LOG and TXT** files (10 MB and 5,000 records per import).
- Parser support for common Wazuh alert fields (`rule.level`, `rule.description`, `data.srcip`, `full_log`) and Suricata EVE alert fields (`src_ip`, `dest_ip`, `dest_port`, `alert.signature`, `alert.severity`). Generic CSV/text records are also supported.
- Three transparent demonstration detection rules: repeated failed logins (5+ in a 10-minute window), possible port scan (8+ distinct destination ports in a 10-minute window), and suspicious keyword matching.
- Alert queue with severity, status (`New`, `In Progress`, `Resolved`, `False Positive`), assignment and analyst notes.
- CSV export of events and a print-ready summary report that can be saved as PDF from the browser.
- Simple demo role split: Admin can import/add records; Admin and Analyst can manage alert triage.
- SQLite storage persists data across restarts. If you need a fresh demonstration database, stop the application and delete `soc_dashboard.db`; it will be recreated with sample records next time it starts.

## Run on Windows 10/11

1. Install Python 3.10 or newer from [python.org](https://www.python.org/downloads/). During setup, select **Add Python to PATH**.
2. Extract this ZIP to a folder you can write to.
3. Double-click `run_windows.bat`, or open Command Prompt in the project folder and run:

   ```bat
   python -m pip install -r requirements.txt
   python app.py
   ```

4. Wait until the terminal says the development server is running on `http://127.0.0.1:5000`.
5. Open **http://127.0.0.1:5000** in Chrome or Edge.
6. Sign in with one of the demo accounts below.

## Run on Linux

```bash
chmod +x run_linux.sh
./run_linux.sh
```

Or use a Python virtual environment and install `requirements.txt` manually. Open `http://127.0.0.1:5000` in a browser.

## Demo login

| Role | Username | Password |
|---|---|---|
| Admin | `admin` | `admin123` |
| Analyst | `analyst` | `analyst123` |

These are demonstration credentials and are deliberately simple for a college lab. **Do not expose this server to the public internet or use these credentials in production.** For a real deployment, implement persistent users with password hashing, CSRF protection, secure cookies, a production WSGI server, TLS, audit logging and stronger access controls.

## Quick demonstration plan

1. Log in as `admin` and review the dashboard metrics and seeded alerts.
2. Open **Security events**, search for `203.0.113.45`, and inspect a record's raw log.
3. Open **Alert queue**, assign an alert to `Security Analyst`, write an investigation note and change its status to `In Progress` or `Resolved`.
4. Open **Log ingestion** and upload one of the included examples from `sample_logs/`.
5. For a correlation-rule demonstration, import `sample_logs/generic_security.csv` or add several manual failed-login events sharing the same source IP; return to the alert queue to see matching rules.
6. Use **Export events CSV** or **Generate report → Print / Save as PDF** to export your results.

All provided IP addresses are from documentation-only TEST-NET ranges. Country values in preloaded data are marked as demo labels and are not verified geolocation.

## Accepted field names

| Normalised field | Common input aliases |
|---|---|
| Timestamp | `timestamp`, `@timestamp`, `time`, `date`, `datetime` |
| Source IP | `source_ip`, `src_ip`, `srcip`, Wazuh `data.srcip` |
| Destination IP | `destination_ip`, `dest_ip`, `dst_ip`, `destip` |
| Destination port | `destination_port`, `dest_port`, `dst_port` |
| Username | `username`, `user`, `data.srcuser`, `data.dstuser` |
| Event message | `message`, `full_log`, `msg`, `description`, Wazuh `rule.description` |
| Severity | `severity`, `level`, Wazuh `rule.level`, Suricata `alert.severity` |
| Source | `source`, Wazuh `agent.name`, `location` |

Import the included Suricata and Wazuh examples to verify their common schema. Real exports may use additional nested fields and may require changing the normalisation function in `app.py`.

## Architecture

```text
Wazuh / Suricata exports / generic CSV or text
                     |
                     v
            Flask ingestion API
                     |
                     v
      Parsing + common event normalisation
                     |
                     v
       SQLite event store (local database)
                     |
                     v
     Rule checks: failed login / port scan / keywords
                     |
                     v
        Alert queue + analyst triage workflow
                     |
                     v
  JavaScript dashboard, charts, CSV and print/PDF report
```

**Synopsis-aligned next step:** deploy Wazuh and Suricata in an isolated Linux/VirtualBox lab, forward logs to a supported collector, then connect this prototype to Elasticsearch/OpenSearch or use the platform's documented API. Threat-intelligence enrichment, live IP geolocation, automated response, machine-learning anomaly detection and enterprise-grade RBAC remain future work.

## Troubleshooting

- **`python` is not recognised:** reinstall Python and select **Add Python to PATH**, or try `py app.py`.
- **ModuleNotFoundError: flask:** run `python -m pip install -r requirements.txt` in the project folder.
- **Port 5000 is already in use:** close the other app, or set a different port before starting. Example PowerShell: `$env:PORT=5050; python app.py`.
- **Reset demo data:** stop the server, delete `soc_dashboard.db`, then restart it.
- **Chart looks blank:** use a current browser with JavaScript enabled and refresh the page.

## Project information

Prepared for the *SOC Monitoring Dashboard* B.Tech (CSE — Cyber Security) mini project, session 2026–27. This implementation is designed for coursework demonstration and authorised lab data only.
