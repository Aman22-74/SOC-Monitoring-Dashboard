from __future__ import annotations

import csv
import hashlib
import io
import json
import os
import re
import sqlite3
from collections import Counter, defaultdict
from datetime import datetime, timedelta, timezone
from functools import wraps
from pathlib import Path
from typing import Any

from flask import (
    Flask, Response, flash, jsonify, redirect, render_template, request,
    send_file, session, url_for,
)

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = Path(os.environ.get("SOC_DB_PATH", BASE_DIR / "soc_dashboard.db"))
APP_SECRET = os.environ.get("SOC_SECRET_KEY", "replace-this-demo-secret-before-deployment")

app = Flask(__name__)
app.secret_key = APP_SECRET
app.config["MAX_CONTENT_LENGTH"] = 10 * 1024 * 1024  # 10 MB import limit

SEVERITY_ORDER = {"Critical": 4, "High": 3, "Medium": 2, "Low": 1, "Info": 0}
VALID_SEVERITIES = set(SEVERITY_ORDER)
VALID_STATUSES = {"New", "In Progress", "Resolved", "False Positive"}
DEMO_USERS = {
    # Demonstration-only credentials. Change these before any deployment.
    "admin": {"password": "admin123", "role": "Admin", "display_name": "SOC Administrator"},
    "analyst": {"password": "analyst123", "role": "Analyst", "display_name": "Security Analyst"},
}


def now_iso() -> str:
    return datetime.now().astimezone().isoformat(timespec="seconds")


def parse_dt(value: str | None) -> datetime | None:
    if not value:
        return None
    try:
        parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        if parsed.tzinfo is None:
            parsed = parsed.astimezone()
        return parsed
    except (ValueError, TypeError):
        return None


def db_conn() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db() -> None:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    with db_conn() as conn:
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT NOT NULL,
                source_ip TEXT NOT NULL DEFAULT 'Unknown',
                destination_ip TEXT NOT NULL DEFAULT 'Unknown',
                destination_port TEXT NOT NULL DEFAULT '',
                username TEXT NOT NULL DEFAULT 'Unknown',
                event_type TEXT NOT NULL DEFAULT 'System Event',
                severity TEXT NOT NULL DEFAULT 'Info',
                source TEXT NOT NULL DEFAULT 'Manual',
                country TEXT NOT NULL DEFAULT 'Unknown',
                message TEXT NOT NULL DEFAULT '',
                raw_log TEXT NOT NULL DEFAULT '{}'
            );
            CREATE INDEX IF NOT EXISTS idx_events_timestamp ON events(timestamp);
            CREATE INDEX IF NOT EXISTS idx_events_src ON events(source_ip);
            CREATE INDEX IF NOT EXISTS idx_events_type ON events(event_type);
            CREATE TABLE IF NOT EXISTS alerts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                fingerprint TEXT NOT NULL UNIQUE,
                title TEXT NOT NULL,
                severity TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'New',
                source_ip TEXT NOT NULL DEFAULT 'Unknown',
                event_type TEXT NOT NULL DEFAULT 'Detection Rule',
                first_seen TEXT NOT NULL,
                last_seen TEXT NOT NULL,
                event_count INTEGER NOT NULL DEFAULT 1,
                assigned_to TEXT NOT NULL DEFAULT 'Unassigned',
                notes TEXT NOT NULL DEFAULT '',
                details TEXT NOT NULL DEFAULT ''
            );
            """
        )
        event_count = conn.execute("SELECT COUNT(*) FROM events").fetchone()[0]
    if event_count == 0:
        seed_demo_data()


def severity_from_any(value: Any, wazuh_level: Any = None, suricata_level: Any = None) -> str:
    if isinstance(value, str):
        text = value.strip().lower()
        for sev in SEVERITY_ORDER:
            if text == sev.lower():
                return sev
        if text in {"4", "1", "critical", "crit"} and text in {"critical", "crit"}:
            return "Critical"
    # Wazuh rule.level: higher values are usually more significant.
    try:
        level = int(wazuh_level)
        if level >= 12:
            return "Critical"
        if level >= 8:
            return "High"
        if level >= 5:
            return "Medium"
        if level >= 3:
            return "Low"
    except (ValueError, TypeError):
        pass
    # Suricata alert.severity is conventionally 1 (high) to 3 (low).
    try:
        level = int(suricata_level)
        if level <= 1:
            return "High"
        if level == 2:
            return "Medium"
        if level >= 3:
            return "Low"
    except (ValueError, TypeError):
        pass
    text = str(value or "").lower()
    if any(k in text for k in ("critical", "ransomware", "malware")):
        return "Critical" if "critical" in text or "ransomware" in text else "High"
    if any(k in text for k in ("high", "brute force", "port scan", "intrusion")):
        return "High"
    if any(k in text for k in ("medium", "warning", "suspicious")):
        return "Medium"
    if "low" in text:
        return "Low"
    return "Info"


def first_value(*values: Any, default: str = "") -> str:
    for value in values:
        if value is not None and str(value).strip() != "":
            return str(value).strip()
    return default


def get_nested(data: dict, *paths: str) -> Any:
    for path in paths:
        current: Any = data
        ok = True
        for part in path.split("."):
            if isinstance(current, dict) and part in current:
                current = current[part]
            else:
                ok = False
                break
        if ok and current not in (None, ""):
            return current
    return None


def normalize_event(record: Any, source_default: str = "Imported") -> dict[str, str]:
    """Convert generic, Wazuh-like, Suricata EVE or CSV records to one schema."""
    if isinstance(record, str):
        text = record.strip()
        ip_match = re.search(r"\b(?:\d{1,3}\.){3}\d{1,3}\b", text)
        lowered = text.lower()
        if any(token in lowered for token in ("failed password", "login failed", "authentication failure", "invalid user")):
            event_type, severity = "Failed Login", "Medium"
        elif any(token in lowered for token in ("port scan", "et scan", "syn scan")):
            event_type, severity = "Port Scan", "High"
        elif any(token in lowered for token in ("malware", "ransomware", "command injection")):
            event_type, severity = "Malware / Suspicious Activity", "High"
        elif "alert" in lowered or "blocked" in lowered:
            event_type, severity = "IDS Alert", "Medium"
        else:
            event_type, severity = "System Event", "Info"
        return {
            "timestamp": now_iso(), "source_ip": ip_match.group(0) if ip_match else "Unknown",
            "destination_ip": "Unknown", "destination_port": "", "username": "Unknown",
            "event_type": event_type, "severity": severity, "source": source_default,
            "country": "Unknown", "message": text[:1000], "raw_log": json.dumps({"line": text}),
        }

    if not isinstance(record, dict):
        record = {"message": str(record)}

    alert_obj = record.get("alert") if isinstance(record.get("alert"), dict) else {}
    rule_obj = record.get("rule") if isinstance(record.get("rule"), dict) else {}
    data_obj = record.get("data") if isinstance(record.get("data"), dict) else {}
    event_obj = record.get("event") if isinstance(record.get("event"), dict) else {}

    timestamp = first_value(
        record.get("timestamp"), record.get("@timestamp"), record.get("time"),
        record.get("date"), record.get("datetime"), default=now_iso()
    )
    parsed_timestamp = parse_dt(timestamp)
    if not parsed_timestamp:
        timestamp = now_iso()
    else:
        # Store a consistent local ISO format so range comparisons work across imported zones.
        timestamp = parsed_timestamp.astimezone().isoformat(timespec="seconds")

    source_ip = first_value(
        record.get("source_ip"), record.get("src_ip"), record.get("srcip"),
        data_obj.get("srcip"), data_obj.get("src_ip"),
        record.get("client_ip"), record.get("remote_addr"),
        default="Unknown",
    )
    destination_ip = first_value(
        record.get("destination_ip"), record.get("dest_ip"), record.get("dst_ip"),
        record.get("destip"), data_obj.get("dstip"), data_obj.get("dst_ip"),
        default="Unknown",
    )
    if source_ip == "Unknown":
        source_ip = first_value(get_nested(record, "src_ip"), get_nested(record, "source.ip"), default="Unknown")
    if destination_ip == "Unknown":
        destination_ip = first_value(get_nested(record, "destination.ip"), default="Unknown")

    port = first_value(record.get("destination_port"), record.get("dest_port"), record.get("dst_port"), record.get("dest_port_num"), default="")
    username = first_value(
        record.get("username"), record.get("user"), data_obj.get("srcuser"), data_obj.get("dstuser"),
        get_nested(record, "user.name"), get_nested(record, "win.eventdata.targetUserName"), default="Unknown"
    )
    raw_type = first_value(record.get("event_type"), record.get("eventType"), event_obj.get("category"), record.get("event_type"), record.get("type"), default="")
    signature = first_value(alert_obj.get("signature"), rule_obj.get("description"), record.get("rule_name"), record.get("signature"), default="")
    message = first_value(record.get("message"), record.get("full_log"), record.get("msg"), record.get("description"), signature, default="Security event imported")

    combined = f"{raw_type} {signature} {message}".lower()
    if any(x in combined for x in ("failed password", "login failed", "authentication failure", "invalid user", "logon failure", "failed login")):
        event_type = "Failed Login"
    elif any(x in combined for x in ("port scan", "et scan", "syn scan", "reconnaissance")):
        event_type = "Port Scan"
    elif any(x in combined for x in ("malware", "ransomware", "command injection", "web attack", "sql injection")):
        event_type = "Malware / Suspicious Activity"
    elif "alert" in combined or "intrusion" in combined or "blocked" in combined:
        event_type = "IDS Alert"
    else:
        event_type = raw_type or ("Suricata Event" if "flow_id" in record else "System Event")
        event_type = str(event_type).replace("_", " ").title()[:80]

    severity = severity_from_any(
        first_value(record.get("severity"), record.get("level"), rule_obj.get("level"), default=""),
        wazuh_level=rule_obj.get("level"),
        suricata_level=alert_obj.get("severity"),
    )
    if event_type == "Failed Login" and severity == "Info":
        severity = "Medium"
    if event_type == "Port Scan" and severity in {"Info", "Low"}:
        severity = "High"

    source = first_value(record.get("source"), record.get("agent", {}).get("name") if isinstance(record.get("agent"), dict) else None, record.get("location"), default=source_default)
    country = first_value(record.get("country"), record.get("geo_country"), get_nested(record, "geoip.country_name"), get_nested(record, "source.geo.country_name"), default="Unknown")
    try:
        raw_log = json.dumps(record, ensure_ascii=False, default=str)
    except (TypeError, ValueError):
        raw_log = str(record)
    return {
        "timestamp": timestamp, "source_ip": source_ip[:100], "destination_ip": destination_ip[:100],
        "destination_port": port[:30], "username": username[:150], "event_type": str(event_type)[:100],
        "severity": severity, "source": source[:120], "country": country[:100],
        "message": str(message)[:1000], "raw_log": raw_log[:12000],
    }


def seed_demo_data() -> None:
    """Seed safe, simulated events using documentation-only TEST-NET IP ranges."""
    now = datetime.now().astimezone()
    events: list[dict[str, str]] = []
    for i in range(7):
        when = now - timedelta(minutes=26 - i * 2)
        events.append(normalize_event({
            "timestamp": when.isoformat(timespec="seconds"), "source_ip": "203.0.113.45",
            "destination_ip": "192.0.2.10", "destination_port": "22", "username": "root",
            "event_type": "Failed Login", "severity": "Medium", "source": "Linux Auth Log",
            "country": "India (demo label)", "message": f"Failed SSH login for user root; attempt {i + 1}",
        }, "Linux Auth Log"))
    for i, port in enumerate([21, 22, 23, 25, 53, 80, 110, 139, 443, 445, 8080]):
        events.append(normalize_event({
            "timestamp": (now - timedelta(minutes=17 - i // 2)).isoformat(timespec="seconds"),
            "source_ip": "198.51.100.17", "destination_ip": "192.0.2.20", "destination_port": str(port),
            "username": "Unknown", "event_type": "Port Scan", "severity": "High", "source": "Suricata EVE",
            "country": "Germany (demo label)", "message": f"Simulated connection attempt to TCP/{port}",
        }, "Suricata EVE"))
    extras = [
        ("192.0.2.88", "192.0.2.10", "alice", "Successful Login", "Info", "Windows Event Log", "Normal interactive login; demo event", "United States (demo label)"),
        ("203.0.113.88", "192.0.2.30", "web-service", "IDS Alert", "High", "Suricata EVE", "ET WEB_SERVER suspicious request pattern (simulated)", "Unknown"),
        ("198.51.100.44", "192.0.2.30", "Unknown", "System Event", "Info", "Web Server", "HTTP 200 request completed", "Singapore (demo label)"),
        ("203.0.113.66", "192.0.2.30", "Unknown", "Malware / Suspicious Activity", "Critical", "Wazuh Alert", "Test rule: suspicious executable name detected (simulated)", "India (demo label)"),
        ("192.0.2.77", "192.0.2.10", "bob", "Password Change", "Low", "Windows Event Log", "A user password change was recorded", "Unknown"),
        ("198.51.100.29", "192.0.2.20", "Unknown", "DNS Query", "Info", "DNS Resolver", "Query for example.test completed", "Unknown"),
        ("203.0.113.90", "192.0.2.30", "Unknown", "IDS Alert", "Medium", "Suricata EVE", "Simulated suspicious HTTP request was logged", "Germany (demo label)"),
        ("192.0.2.91", "192.0.2.10", "svc-backup", "System Event", "Low", "Linux Syslog", "Scheduled backup job completed", "Unknown"),
    ]
    for offset, row in enumerate(extras):
        src, dst, user, typ, sev, source, msg, country = row
        events.append(normalize_event({
            "timestamp": (now - timedelta(minutes=offset * 3 + 4)).isoformat(timespec="seconds"),
            "source_ip": src, "destination_ip": dst, "username": user, "event_type": typ,
            "severity": sev, "source": source, "message": msg, "country": country,
        }, source))
    with db_conn() as conn:
        for event in events:
            insert_event(conn, event, run_detection=False)
        # Seed a correlated queue consistent with the repeated demo events.
        create_or_update_alert(conn, "bruteforce:203.0.113.45:root", "Possible brute-force login", "High",
                               "203.0.113.45", "Failed Login", events[0]["timestamp"], events[6]["timestamp"], 7,
                               "Multiple failed SSH login attempts for root were observed in the sample data.")
        create_or_update_alert(conn, "portscan:198.51.100.17", "Possible port scan", "High",
                               "198.51.100.17", "Port Scan", events[7]["timestamp"], events[17]["timestamp"], 11,
                               "Multiple destination ports were contacted in a short period in the sample data.")
        create_or_update_alert(conn, "signature:203.0.113.66:demo-malware", "Suspicious executable indicator", "Critical",
                               "203.0.113.66", "Malware / Suspicious Activity", events[-5]["timestamp"], events[-5]["timestamp"], 1,
                               "Synthetic rule match included for demonstrating severity and alert triage.")


def create_or_update_alert(conn: sqlite3.Connection, fingerprint: str, title: str, severity: str,
                           source_ip: str, event_type: str, first_seen: str, last_seen: str,
                           event_count: int, details: str) -> None:
    existing = conn.execute("SELECT id, status, event_count FROM alerts WHERE fingerprint=?", (fingerprint,)).fetchone()
    if existing:
        # When the same detection fires again, keep analyst status and accumulate evidence.
        conn.execute(
            "UPDATE alerts SET last_seen=?, event_count=MAX(event_count, ?), severity=?, details=? WHERE id=?",
            (last_seen, event_count, severity, details, existing["id"]),
        )
    else:
        conn.execute(
            """INSERT INTO alerts (fingerprint,title,severity,status,source_ip,event_type,first_seen,last_seen,event_count,details)
               VALUES (?,?,?,'New',?,?,?,?,?,?)""",
            (fingerprint, title, severity, source_ip, event_type, first_seen, last_seen, event_count, details),
        )


def insert_event(conn: sqlite3.Connection, event: dict[str, str], run_detection: bool = True) -> int:
    cursor = conn.execute(
        """INSERT INTO events (timestamp,source_ip,destination_ip,destination_port,username,event_type,severity,source,country,message,raw_log)
           VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
        (event["timestamp"], event["source_ip"], event["destination_ip"], event["destination_port"],
         event["username"], event["event_type"], event["severity"], event["source"], event["country"],
         event["message"], event["raw_log"]),
    )
    event_id = int(cursor.lastrowid)
    if run_detection:
        run_rules_for_event(conn, event)
    return event_id


def run_rules_for_event(conn: sqlite3.Connection, event: dict[str, str]) -> None:
    timestamp = parse_dt(event["timestamp"]) or datetime.now().astimezone()
    start = (timestamp - timedelta(minutes=10)).isoformat(timespec="seconds")
    source_ip = event["source_ip"]
    if source_ip == "Unknown":
        return

    failed_rows = conn.execute(
        """SELECT timestamp, username, message FROM events
           WHERE source_ip=? AND event_type='Failed Login' AND timestamp>=? AND timestamp<=? ORDER BY timestamp DESC""",
        (source_ip, start, timestamp.isoformat(timespec="seconds")),
    ).fetchall()
    by_user: dict[str, list[sqlite3.Row]] = defaultdict(list)
    for row in failed_rows:
        # Keep per-user correlation to avoid merging unrelated accounts.
        found = re.search(r"(?:for\s+user\s+|user\s+|for\s+|account\s+)['\"]?([A-Za-z0-9_.@\\-]+)", row["message"], re.I)
        candidate = found.group(1) if found else event["username"]
        by_user[candidate].append(row)
    for user, rows in by_user.items():
        if len(rows) >= 5:
            latest = rows[0]["timestamp"]
            earliest = rows[-1]["timestamp"]
            create_or_update_alert(
                conn, f"bruteforce:{source_ip}:{user}", "Possible brute-force login", "High", source_ip,
                "Failed Login", earliest, latest, len(rows),
                f"{len(rows)} failed-login events from {source_ip} for account '{user}' occurred within a 10-minute window.",
            )

    port_rows = conn.execute(
        """SELECT timestamp, destination_port FROM events
           WHERE source_ip=? AND timestamp>=? AND timestamp<=? AND destination_port<>'' ORDER BY timestamp DESC""",
        (source_ip, start, timestamp.isoformat(timespec="seconds")),
    ).fetchall()
    ports = {row["destination_port"] for row in port_rows}
    if len(ports) >= 8:
        create_or_update_alert(
            conn, f"portscan:{source_ip}", "Possible port scan", "High", source_ip, "Port Scan",
            port_rows[-1]["timestamp"], port_rows[0]["timestamp"], len(port_rows),
            f"{len(ports)} distinct destination ports were observed from {source_ip} within a 10-minute window.",
        )

    suspicious = any(word in (event["message"] + " " + event["event_type"]).lower()
                     for word in ("malware", "ransomware", "command injection", "sql injection", "suspicious executable"))
    if suspicious:
        fp = f"signature:{source_ip}:{hashlib.sha1(event['message'].encode('utf-8', 'ignore')).hexdigest()[:10]}"
        create_or_update_alert(
            conn, fp, "Suspicious activity matched a detection rule", event["severity"] if event["severity"] != "Info" else "High",
            source_ip, event["event_type"], event["timestamp"], event["timestamp"], 1,
            "A rule matched a suspicious keyword in the event. This is a demonstration rule and needs analyst validation.",
        )


def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if "username" not in session:
            return redirect(url_for("login", next=request.path))
        return view(*args, **kwargs)
    return wrapped


def role_required(*roles):
    def decorator(view):
        @wraps(view)
        def wrapped(*args, **kwargs):
            if "username" not in session:
                return jsonify({"error": "Authentication required"}), 401
            if session.get("role") not in roles:
                return jsonify({"error": "Your role is not permitted to perform this action."}), 403
            return view(*args, **kwargs)
        return wrapped
    return decorator


def current_user() -> dict[str, str]:
    return {"username": session.get("username", ""), "role": session.get("role", ""),
            "display_name": session.get("display_name", session.get("username", ""))}


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "").strip().lower()
        password = request.form.get("password", "")
        user = DEMO_USERS.get(username)
        if user and password == user["password"]:
            session.clear()
            session.update(username=username, role=user["role"], display_name=user["display_name"])
            destination = request.args.get("next", "")
            if not destination.startswith("/") or destination.startswith("//"):
                destination = url_for("index")
            return redirect(destination)
        flash("Invalid username or password. Use one of the demo accounts shown on this page.", "error")
    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


@app.route("/")
@login_required
def index():
    return render_template("index.html", user=current_user())


@app.get("/api/summary")
@login_required
def api_summary():
    with db_conn() as conn:
        total = conn.execute("SELECT COUNT(*) FROM events").fetchone()[0]
        open_alerts = conn.execute("SELECT COUNT(*) FROM alerts WHERE status IN ('New','In Progress')").fetchone()[0]
        high_alerts = conn.execute("SELECT COUNT(*) FROM alerts WHERE severity IN ('Critical','High') AND status IN ('New','In Progress')").fetchone()[0]
        sources = conn.execute("SELECT COUNT(DISTINCT source_ip) FROM events WHERE source_ip<>'Unknown'").fetchone()[0]
        severity_rows = conn.execute("SELECT severity, COUNT(*) count FROM events GROUP BY severity").fetchall()
        event_rows = conn.execute("SELECT event_type, COUNT(*) count FROM events GROUP BY event_type ORDER BY count DESC LIMIT 6").fetchall()
        top_sources = conn.execute("SELECT source_ip, COUNT(*) count FROM events WHERE source_ip<>'Unknown' GROUP BY source_ip ORDER BY count DESC LIMIT 6").fetchall()
        countries = conn.execute("SELECT country, COUNT(*) count FROM events WHERE country<>'Unknown' GROUP BY country ORDER BY count DESC LIMIT 6").fetchall()
        recent_alerts = conn.execute("SELECT * FROM alerts ORDER BY CASE severity WHEN 'Critical' THEN 4 WHEN 'High' THEN 3 WHEN 'Medium' THEN 2 ELSE 1 END DESC, last_seen DESC LIMIT 6").fetchall()
        recent_events = conn.execute("SELECT * FROM events ORDER BY timestamp DESC, id DESC LIMIT 8").fetchall()
        trend_rows = conn.execute("SELECT timestamp, severity FROM events WHERE timestamp>=? ORDER BY timestamp", ((datetime.now().astimezone()-timedelta(days=6)).isoformat(timespec="seconds"),)).fetchall()
    trend_buckets: dict[str, dict[str, int]] = {}
    for day_offset in range(6, -1, -1):
        day = (datetime.now().astimezone().date() - timedelta(days=day_offset)).isoformat()
        trend_buckets[day] = {"date": day, "events": 0, "high": 0}
    for row in trend_rows:
        dt = parse_dt(row["timestamp"])
        if dt:
            day = dt.date().isoformat()
            if day in trend_buckets:
                trend_buckets[day]["events"] += 1
                if row["severity"] in ("High", "Critical"):
                    trend_buckets[day]["high"] += 1
    with db_conn() as conn:
        alert_statuses = conn.execute("SELECT status, COUNT(*) count FROM alerts GROUP BY status").fetchall()
    return jsonify({
        "metrics": {"total_events": total, "open_alerts": open_alerts, "high_alerts": high_alerts, "unique_sources": sources},
        "severity": [{"name": r["severity"], "value": r["count"]} for r in severity_rows],
        "event_types": [{"name": r["event_type"], "value": r["count"]} for r in event_rows],
        "top_sources": [{"name": r["source_ip"], "value": r["count"]} for r in top_sources],
        "countries": [{"name": r["country"], "value": r["count"]} for r in countries],
        "alerts": [dict(row) for row in recent_alerts], "events": [dict(row) for row in recent_events],
        "trend": list(trend_buckets.values()),
        "alert_statuses": [{"name": r["status"], "value": r["count"]} for r in alert_statuses],
        "demo_mode": True,
    })


@app.get("/api/events")
@login_required
def api_events():
    q = request.args.get("q", "").strip()[:200]
    severity = request.args.get("severity", "").strip()
    event_type = request.args.get("event_type", "").strip()
    limit = min(max(int(request.args.get("limit", 250) or 250), 1), 1000)
    sql = "SELECT * FROM events WHERE 1=1"
    params: list[Any] = []
    if q:
        sql += " AND (source_ip LIKE ? OR destination_ip LIKE ? OR username LIKE ? OR message LIKE ? OR source LIKE ? OR event_type LIKE ?)"
        params.extend([f"%{q}%"] * 6)
    if severity in VALID_SEVERITIES:
        sql += " AND severity=?"
        params.append(severity)
    if event_type:
        sql += " AND event_type=?"
        params.append(event_type)
    sql += " ORDER BY timestamp DESC, id DESC LIMIT ?"
    params.append(limit)
    with db_conn() as conn:
        rows = conn.execute(sql, params).fetchall()
        types = conn.execute("SELECT DISTINCT event_type FROM events ORDER BY event_type").fetchall()
    return jsonify({"events": [dict(row) for row in rows], "event_types": [r[0] for r in types]})


@app.get("/api/alerts")
@login_required
def api_alerts():
    q = request.args.get("q", "").strip()[:200]
    status = request.args.get("status", "").strip()
    severity = request.args.get("severity", "").strip()
    sql = "SELECT * FROM alerts WHERE 1=1"
    params: list[Any] = []
    if q:
        sql += " AND (title LIKE ? OR source_ip LIKE ? OR details LIKE ? OR assigned_to LIKE ?)"
        params.extend([f"%{q}%"] * 4)
    if status in VALID_STATUSES:
        sql += " AND status=?"
        params.append(status)
    if severity in VALID_SEVERITIES:
        sql += " AND severity=?"
        params.append(severity)
    sql += " ORDER BY CASE severity WHEN 'Critical' THEN 4 WHEN 'High' THEN 3 WHEN 'Medium' THEN 2 WHEN 'Low' THEN 1 ELSE 0 END DESC, last_seen DESC"
    with db_conn() as conn:
        rows = conn.execute(sql, params).fetchall()
    return jsonify({"alerts": [dict(row) for row in rows]})


@app.post("/api/alerts/<int:alert_id>")
@login_required
@role_required("Admin", "Analyst")
def update_alert(alert_id: int):
    payload = request.get_json(silent=True) or request.form.to_dict()
    status = str(payload.get("status", "")).strip()
    assigned_to = str(payload.get("assigned_to", "")).strip()[:120]
    notes = str(payload.get("notes", "")).strip()[:4000]
    if status and status not in VALID_STATUSES:
        return jsonify({"error": "Invalid alert status."}), 400
    with db_conn() as conn:
        existing = conn.execute("SELECT * FROM alerts WHERE id=?", (alert_id,)).fetchone()
        if not existing:
            return jsonify({"error": "Alert not found."}), 404
        conn.execute("UPDATE alerts SET status=?, assigned_to=?, notes=? WHERE id=?",
                     (status or existing["status"], assigned_to or existing["assigned_to"], notes, alert_id))
        updated = conn.execute("SELECT * FROM alerts WHERE id=?", (alert_id,)).fetchone()
    return jsonify({"alert": dict(updated), "message": "Alert updated."})


def parse_uploaded_content(filename: str, text: str) -> list[Any]:
    suffix = Path(filename.lower()).suffix
    content = text.lstrip("\ufeff\n\r\t ")
    if not content:
        return []
    if suffix == ".csv" or ("\n" in content and "," in content.splitlines()[0] and not content.lstrip().startswith(("{", "["))):
        reader = csv.DictReader(io.StringIO(content))
        return [row for row in reader]
    if suffix in {".json", ".jsonl", ".ndjson"} or content.startswith(("{", "[")):
        try:
            data = json.loads(content)
            if isinstance(data, list):
                return data
            if isinstance(data, dict):
                # Common Wazuh alert export can wrap entries in an "alerts" or "events" array.
                for key in ("events", "alerts", "records", "data"):
                    if isinstance(data.get(key), list):
                        return data[key]
                return [data]
        except json.JSONDecodeError:
            pass
    records = []
    for line in content.splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            parsed = json.loads(line)
            records.append(parsed)
        except json.JSONDecodeError:
            records.append(line)
    return records


@app.post("/api/ingest")
@login_required
@role_required("Admin")
def ingest_file():
    if "file" not in request.files:
        return jsonify({"error": "Choose a JSON, JSONL, CSV or text log file."}), 400
    file = request.files["file"]
    if not file.filename:
        return jsonify({"error": "Choose a file to upload."}), 400
    if Path(file.filename).suffix.lower() not in {".json", ".jsonl", ".ndjson", ".csv", ".log", ".txt"}:
        return jsonify({"error": "Supported formats: JSON, JSONL/NDJSON, CSV, LOG and TXT."}), 400
    try:
        text = file.read().decode("utf-8", errors="replace")
        records = parse_uploaded_content(file.filename, text)
        if not records:
            return jsonify({"error": "No log records were found in this file."}), 400
        if len(records) > 5000:
            return jsonify({"error": "This demo accepts up to 5,000 records per import."}), 400
        source_default = Path(file.filename).stem[:100] or "Imported"
        normalized = [normalize_event(record, source_default) for record in records]
        with db_conn() as conn:
            for event in normalized:
                insert_event(conn, event)
        return jsonify({"message": f"Imported {len(normalized)} log record(s). Detection rules were evaluated.", "imported": len(normalized)})
    except Exception as exc:  # Keep the UI usable; don't expose stack traces to a user.
        app.logger.exception("Log import failed")
        return jsonify({"error": f"Import failed: {type(exc).__name__}. Check the file format and try again."}), 500


@app.post("/api/events")
@login_required
@role_required("Admin")
def add_manual_event():
    payload = request.get_json(silent=True) or request.form.to_dict()
    message = str(payload.get("message", "")).strip()
    if not message:
        return jsonify({"error": "Event message is required."}), 400
    payload["timestamp"] = payload.get("timestamp") or now_iso()
    payload["source"] = payload.get("source") or "Manual Entry"
    payload["event_type"] = payload.get("event_type") or "System Event"
    payload["severity"] = payload.get("severity") or "Info"
    event = normalize_event(payload, "Manual Entry")
    with db_conn() as conn:
        event_id = insert_event(conn, event)
    return jsonify({"message": "Event added and detection rules evaluated.", "event_id": event_id})


@app.get("/export/events.csv")
@login_required
def export_events():
    with db_conn() as conn:
        rows = conn.execute("SELECT id,timestamp,source_ip,destination_ip,destination_port,username,event_type,severity,source,country,message FROM events ORDER BY timestamp DESC").fetchall()
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["ID", "Timestamp", "Source IP", "Destination IP", "Destination Port", "Username", "Event Type", "Severity", "Source", "Country", "Message"])
    for row in rows:
        writer.writerow(list(row))
    filename = f"soc-events-{datetime.now().strftime('%Y%m%d-%H%M%S')}.csv"
    return Response(output.getvalue(), mimetype="text/csv; charset=utf-8",
                    headers={"Content-Disposition": f"attachment; filename={filename}"})


@app.get("/report")
@login_required
def report():
    with db_conn() as conn:
        metrics = {
            "events": conn.execute("SELECT COUNT(*) FROM events").fetchone()[0],
            "open_alerts": conn.execute("SELECT COUNT(*) FROM alerts WHERE status IN ('New','In Progress')").fetchone()[0],
            "high_alerts": conn.execute("SELECT COUNT(*) FROM alerts WHERE severity IN ('High','Critical') AND status IN ('New','In Progress')").fetchone()[0],
        }
        alerts = conn.execute("SELECT * FROM alerts ORDER BY last_seen DESC LIMIT 100").fetchall()
        top_sources = conn.execute("SELECT source_ip, COUNT(*) AS count FROM events WHERE source_ip<>'Unknown' GROUP BY source_ip ORDER BY count DESC LIMIT 10").fetchall()
        events = conn.execute("SELECT * FROM events ORDER BY timestamp DESC LIMIT 25").fetchall()
    return render_template("report.html", metrics=metrics, alerts=alerts, top_sources=top_sources,
                           events=events, generated=now_iso(), user=current_user())


@app.get("/health")
def health():
    return jsonify({"status": "ok", "application": "SOC Monitoring Dashboard", "mode": "local-demo"})


@app.errorhandler(413)
def file_too_large(_error):
    if request.path.startswith("/api/"):
        return jsonify({"error": "File too large. Maximum upload size is 10 MB."}), 413
    return "File too large. Maximum upload size is 10 MB.", 413


init_db()

if __name__ == "__main__":
    # Local development only. Use a production WSGI server for real deployments.
    app.run(host="127.0.0.1", port=int(os.environ.get("PORT", "5000")), debug=False)
